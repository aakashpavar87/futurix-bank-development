import React from 'react'

const ProfileSettings = () => {
  return (
    <div className='text-5xl mt-52 bg-[#00040f] text-red-600'>This is setting page</div>
  )
}

export default ProfileSettings