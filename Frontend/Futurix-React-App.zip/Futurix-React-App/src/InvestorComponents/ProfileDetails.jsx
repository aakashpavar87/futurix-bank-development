export const ProfileDetails = () => {
    return (
        <div className="flex flex-col justify-end text-right">
            <span className="text-lg font-semibold">John Doe</span>
            <span className="text-sm">john.doe@example.com</span>
            {/* Add other profile details here */}
        </div>
    );
}