package com.futurix.filestorage;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfileImageRepo extends JpaRepository<ProfileImageData, Integer> {

}
