package com.futurix.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.futurix.entities.TblBusiness_loan;

public interface BusinessLoanRepo extends JpaRepository<TblBusiness_loan, Integer> {

}
