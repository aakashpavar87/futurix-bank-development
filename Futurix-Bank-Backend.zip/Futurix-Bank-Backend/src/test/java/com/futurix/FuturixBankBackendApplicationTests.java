package com.futurix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuturixBankBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
